#!/bin/bash
#
#  install modules for base apps
#
#############
#
echo
echo "cloud: install node js modules"
npm install --save --verbose
echo "ho eseguito:  npm install for node js cloud system"
echo "-----------------------------"
echo 