
module.exports = function (req, res,next) {
//--------------------------------------------------------------------------------------------------

//  Internal homepage
app.get('/', async (req, res, next) => {
  try {
    res.type('.html')
    res.write('Hello, I am syslog, listening on port '+http_port+' ! <br>');
    const log_value = await getvar(gtbase_logvar);
    res.write('Debug string:<br>'+log_value+'<br><br>');
    res.write('You called user\'s home page with query parameters:<br>'+JSON.stringify(req.query));
    res.end();
    next();
  } catch (error) {
    next(error);    
  }
});

//--------------------------------------------------------------------------------------------------
};
