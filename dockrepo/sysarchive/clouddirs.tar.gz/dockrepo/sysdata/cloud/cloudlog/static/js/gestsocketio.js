/* 
 * gestione canale socket.io
 * 
 *   versione per lista discovery da bootinit.py
 *   
 *     
 */

// variabili che devono essere definite dal server nel template della pagina:
// 
//    liveurl          '<%= liveurl %>'
//    udplista         []
//    usersocketid 
//    username         '<%= user.username %>'
//    displayName      '<%= user.displayName %>'
//    csrfToken        '<%= csrfToken %>'
//    sessionid        '<%= sessionid %>'
//    sid              '<%= sid %>'
//    istz             '<%= istz %>'
//  
//  
 var versione = '0.0.3'             //- numerazione interna, per debug
   , server_msg_count = 0           //- contatori vari per il display
   , nodo_msg_count = 0
   , max_nodo_msg_count = 10
   , spam_msg_count = 0
   , max_spam_msg_count = 10
   , userlist, userlist_msg_count = 0, max_userlist_msg_count = 10
   , lista_msg_count = 0
   , max_lista_msg_count = 10
   , serverBaseUrl = document.domain
   , socket
 ;

function buttonclick(button){
  //alert(button);
  if(typeof button === 'string'){
    var userobj = {istz: istz, id: usersocketid, cmd: button};
    sendMessageAuth({type:'usercmd', msg: userobj}); //--- messaggio di autenticazione al server
    console.log('gestsocketio - posted user command to server: '+JSON.stringify(userobj));
    return false;
  }else{
    console.log('gestsocketio - command messagefrom button is invalid');
  }
}

function safeJSONparse(payload){ try{//---  se non ci sono errori ritorna l'oggetto JSON, altrimenti false 
    var p = JSON.parse(payload);
    return p;
  }catch(myError) {
    console.log('catch_error() - ERRORE safeJSON.parse(): ' + myError.name + ' | Message:' + myError.message);
    return false;
}};

function nodo_html(p){//--- versione html del pacchetto UDP
  //  serial sname cname bootnum ipaddress:port rxport status st2 last password count
  var h;
  h = '<div style="overflow:visible;">';
  h +=   '<span style="display:inline-block;width:3em;">'+p.msg_count+': </span>';
  h +=   '<span style="display:inline-block;width:10em;">'+p.serial+'</span>';
  h +=   '<span style="display:inline-block;width:8em;">'+p.sname+'</span>';
  h +=   '<span style="display:inline-block;width:10em;">'+p.cname+'</span>';
  h +=   '<span style="display:inline-block;width:6em;">'+p.bootnum+'</span>';
  h +=   '<span style="display:inline-block;width:12em;">'+p.address+':'+p.port+'</span>';
  h +=   '<span style="display:inline-block;width:9em;">'+p.status+'</span>';
  h +=   '<span style="display:inline-block;width:10em;">'+p.last+'</span>';
  h +=   '<span style="display:inline-block;width:10em;">'+p.count+'</span>';
  h += '</div>';
  return h;
}

function makelist(lista){//----  converti oggetto in lista di paragrafi html
  var pri = '<p>'
    , poi = '</p>\n'
    , txt = ''
    , a
  ;
  for (var i in lista) {
    if (lista.hasOwnProperty(i)) {
      a = JSON.stringify(lista[i])
      if(a !== 'null') txt += pri+i+': '+a+poi;
    }
  }
  if(txt === '') txt = 'nessun elemento';
  return txt;
}

/*
 ***  spedizione di un messaggio autorizzato al server  ***
 * 
 * formato messaggio:   {type:'messagetype', msg: {istz: istz, .... } }
 *     msgtype:          classe del messaggio, interpretata dal server
 *     istz              identificativo della finestra browser
 *     ......            altre variabili da consegnare al server
 *  tipi definiti:
 *     {type: 'userid', msg: {id: usersocketid, istz: istz, sid: sid, usrid: usrid} }
 *        <-- {type: 'userid', msg: {istz: istz, sock: sock} }
*/
//----  utility function for server response to messages
$.ajaxSetup({
  headers: {
    'X-CSRF-Token': csrfToken
  }
});


function sendMessageAuth(outgoingMessage) {
  console.log('gestsocketio - init - function sendMessage - msg: '+JSON.stringify(outgoingMessage));
  $.ajax({
    url:  '/admin',
    type: 'POST',
    contentType: 'application/json',
    dataType: 'json',
    data: JSON.stringify(outgoingMessage)
  });
}

$(document).ajaxSuccess(function(event, xhr, settings) {
  var resp = xhr.responseJSON
    , istz
  ;
  if(typeof resp !== 'undefined' && typeof resp.type === 'string' && typeof resp.msg === 'object'){
    console.log('gestsocketio - ajax success - msg: '+JSON.stringify(resp.msg));
    console.log('gestsocketio - ajax success - type: '+resp.type);
    istz = parseInt(resp.msg.istz, 10);
    if(istz === 'undefined' || istz <= 0){
      console.log('gestsocketio - ajax success - POST adminAuth BAD DATA - istz: '+istz);
      return;
    }else{
      if(istz !== istz){
        console.log('gestsocketio - ajax success - POST adminAuth BAD DATA - invalid istz: '+istz);
        return;
      }
    }
    switch(resp.type){
      case "userid":
        if(resp.msg.sock === 'undefined' || resp.msg.sock <= 0){
          console.log('gestsocketio - ajax success - POST adminAuth BAD DATA - sock: '+resp.msg.sock);
          return;
        }else{
          sock = resp.msg.sock;
          $('#sock').text(sock);
        }
        console.log('gestsocketio - ajax success - sock: '+resp.msg.sock);
        break;
      default:
        console.log('gestsocketio - ajax success - unrecognized type: '+resp.type);
        break;
    }
  }else{//--- risposta da adminauth malformata
    console.log('gestsocketio - ajax success - ERRORE - xhr: '+JSON.stringify(xhr));
  }
});

$( document ).ajaxError(function(event, xhr, settings) {
  var resp = xhr.responseText
  ;
  console.log('gestsocketio - ajax ERROR - xhr: '+JSON.stringify(xhr));
  if(resp.status === 410){
    console.log('gestsocketio - ajax ERROR - resp.status: '+resp.status);
    clearInterval(tick);
  }
  if(resp.status === 404){
    console.log('gestsocketio - ajax ERROR - resp.status: '+resp.status);
    clearInterval(tick);
  }
});

function admin_init() {
  console.log('gestsocketio - start admin_init() - liveurl: '+liveurl);
  console.log('gestsocketio - start admin_init() - sessionid: '+sessionid);
  $('#csrfToken').text(csrfToken);//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@  aggiustare admin.ejs  @@@@@@@@@@@@@@@@

  socket = io.connect(liveurl);//   On client init, try to connect to the socket.IO server.

/*
 * Connessione iniziale - manda usersocketid al server, ci ritornera' il sock
 * --> se sock rimane === 0 qualcosa NON HA FUNZIONATO !!!
 * 
 */
  socket.on('connect', function () {// Connessione iniziale al server
    usersocketid = socket.io.engine.id;
    console.log('gestsocketio - connect function - new socket id: '+usersocketid);
    $('#usersocketid').text(usersocketid);//--- vedi admin.ejs / footeradmin
    var userobj = {istz: istz, id: usersocketid, sid: sid, usrid: usrid};
    sendMessageAuth({type:'userid', msg: userobj}); //--- messaggio di autenticazione al server
    console.log('gestsocketio - posted user object to server: '+JSON.stringify(userobj));
    $('.message').text('*** zona lista ***')
  });

/*
 * Ricezione messaggio dal server
 * 
*/
  socket.on('ioMessage', function (data) {//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ AGGIUSTARE
  //@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ per ora si aggiungono TUTTE le segnalazioni  @@@@
    //--- Ricevuto un messaggio dal server, metterlo in cima alla lista
    //--- elimina veccio elemento
    //--- aggiungi nuovo in cima alla lista
    var a = JSON.stringify(data)
      , txt
      , pre, post
      , p = {};
    ;
    server_msg_count++;
    console.log('gestsocketio - inizio - ioMessage '+server_msg_count+': '+a);
    // caso data.nodo                                                                               *** DA AGGIUSTARE  ***
    if(typeof data.nodo !== 'undefined' && data.nodo.length > 0){//--- aggiorna lista messaggi ricevuti
      nodo_msg_count++;
      p = safeJSONparse(data.nodo);
      console.log('gestsocketio - messaggio nodo: '+JSON.stringify(p));
      p.msg_count = nodo_msg_count;
      pre = '<div class="u_message" style="display: inline-block; margin: 5px; padding: 5px;">';
      post = '</div>';
      $('#messagelist').prepend(pre+nodo_html(p)+post);
      if(nodo_msg_count > max_nodo_msg_count){
        $('.u_message:last').remove();
        //console.log('gestsocketio - cancellato ultimo messaggio');
      }
      return;
    }
    type = data.type;
    if(typeof type === 'undefined' || type.length < 1) return;
    console.log('gestsocketio - ioMessage - tipo messaggio: '+type);
    switch(type){
      case "userlist":
        console.log('gestsocketio - ioMessage - messaggio userlist:\n'+JSON.stringify(data.msg));
        $('#utenti').html(makelist(safeJSONparse(data.msg)));
        break;
      case "socketlist":
        console.log('gestsocketio - ioMessage - messaggio socketlist:\n'+JSON.stringify(data.msg));
        $('#sockets').html(makelist(safeJSONparse(data.msg)));
        break;
      case "sessionlist":
        console.log('gestsocketio - ioMessage - messaggio sessionlist:\n'+JSON.stringify(data.msg));
        $('#sessions').html(makelist(safeJSONparse(data.msg)));
        break;
      case "istanze":
        console.log('gestsocketio - ioMessage - messaggio lista istanze:\n'+JSON.stringify(data.msg));
        $('#instances').html(makelist(safeJSONparse(data.msg)));
        break;
      case "hliteerror":
        console.log('gestsocketio - ioMessage - messaggio di errore:\n'+JSON.stringify(data.msg));
        $('#hliteerror').html(safeJSONparse(data.msg));
        break;
      default:
        console.log('gestsocketio - ioMessage - messaggio '+server_msg_count+' - type: '+type+' ignorato !!');
        break;
    }
  });

  /*
    Log an error if unable to connect to server
  */
  socket.on('error', function (reason) {
    console.log('gestsocketio - Unable to connect to server', reason);
  });
}

var tick                    //---  contatore watchdog
  , tick_interval = 500    //---  intervallo watchdog
  , tick_count = 0
;

function start_periodic_tick(intervallo){
  var p = intervallo
  console.log('TICK timer executed every '+intervallo/1000+' secondi');
  return setInterval(function(){
    ;
    tick_count++;
    if(tick_count < 10) console.log('timer TICK '+tick_count);
    if(tick_count % 2){
      console.log('emit clientLive '+tick_count);
      socket.emit('clientLive',{istz:istz, socket: usersocketid, sid: sid, usrid: usrid});
    }else{
      console.log('post clientLive '+tick_count);
      sendMessageAuth({type: 'clientLive',msg:{istz:istz, socket: usersocketid, sid: sid, usrid: usrid}});
    }
  }, p);
}

clearInterval(tick);
tick = start_periodic_tick(tick_interval);// esecuzione periodica di funzioni varie

$(document).on('ready', 
  admin_init
);
