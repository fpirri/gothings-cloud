/* 
 * gestione simulatore NetAlarm2
 * 
 *   versione iniziale X demo mar 12, 2016
 *   
 *     
 */

// variabili inizializzate tutte a mano
// 
//    curl -X POST -d "{type:'1.1.0', id:'<seriale della macchina>'}" 10.8.0.1:8001/netalarm2
//
var versione = '0.0.5'           //- numerazione interna, per debug
  , tick                         //---  contatore watchdog
  , tick_interval = 1000         //---  intervallo watchdog
  , tick_count = 0
  , na2server = 'http://10.8.0.1:8001/netalarm2'
  , seriale = 'sim-0123'
  , seriale_last = seriale
  , livemsg = {type:'1.1.0', id:seriale}
  , alarmmsg = {type: "2.1.0", id: seriale, alarm: 1, a_msg: "messaggio allarme"}
  , msgliveon = {type:'1.1.0', id:seriale, live:true}
  , msgliveoff = {type:'1.1.0', id:seriale, live:false}
  , simulmsg = {type:'simul', id:seriale, op: 'nop'}
  , live_ok = false
  , live_ok_last = live_ok
  , live_interval = 15
  , alarm_msg = 'Un qualunque messaggio di allarme'
  , alarm_level = 1
;

function readvalues(){
  live_ok = $('#serialeswitch').is(':checked');
  msgliveon.live = msgliveoff.live = live_ok;
  live_interval = $('#tempo').prop('value');
  alarm_msg = $('#allarme').prop('value');
  alarmmsg.msg = alarm_msg;
  alarm_level = $('#livello').prop('value');
  alarmmsg.alarm = alarm_level;
  seriale = $('#seriale').prop('value');
  livemsg.id = msgliveon.id = msgliveoff.id = simulmsg.id = seriale_last.id = alarmmsg.id = seriale;
}

function start_periodic_tick(intervallo){
  var p = intervallo
    , chg = 0;
  console.log('TICK timer executed every '+intervallo/1000+' secondi');
  return setInterval(function(){
    tick_count++;
    $('#tick_count').text(tick_count);
    readvalues();
    if(live_ok && !live_ok_last) {//---  live da mandare subito!
      console.log('####################### Richiedi al server di emettere un send live');
      sendMessage(livemsg);
    }
    live_ok_last = live_ok;
    if(live_ok && live_interval > 1 && tick_count % live_interval === 0){// funzione X emissione ripetuta live msg
      console.log('live message tick: '+tick_count);
      sendMessage(livemsg);
    }
    //sendMessage(simulmsg);
    //-------------------------------------------------------------------  Altre azioni temporizzate
    if(tick_count % 5 === 0){// funzione eseguita per ogni 5 tick del timer
      //console.log('t5. . .  '+tick_count);
    }
    if(tick_count % 10 === 0){
      //console.log('t10. . .  '+tick_count);
    }
    if(tick_count % 15 === 0){
      //console.log('t15. . .  '+tick_count);
    }
    if(tick_count % 20 === 0){
      //console.log('t20. . .  '+tick_count);
    }
    if(tick_count % 50 === 0){
      console.log('t50. . .  '+tick_count);
      showvalues()
    }
    if(tick_count % 100 === 0){
      console.log('t100. . .  '+tick_count);
      //showvalues()
    }
  }, p);
}
clearInterval(tick);
//tick = start_periodic_tick(tick_interval);// esecuzione periodica di funzioni varie

function showvalues(){
  console.log('      live_ok: '+live_ok);
  console.log('live_interval: '+live_interval);
  console.log('alarm message: '+alarm_msg);
  console.log('  alarm level: '+alarm_level);  
}

function switchlamp(el){
  $( "#"+el ).toggle(function() {
    $( this ).css( "background-color", 'red' );
  }, function() {
    $( this ).css( "background-color", 'green' );
  });
}

function safeJSONparse(payload){ try{//---  se non ci sono errori ritorna l'oggetto JSON, altrimenti false 
    var p = JSON.parse(payload);
    return p;
  }catch(myError) {
    console.log('catch_error() - ERRORE safeJSON.parse(): ' + myError.name + ' | Message:' + myError.message);
    return false;
}};

/*
 ***  spedizione di un messaggio JSON al server  ***
 * 
 * formato messaggio:  vedi specifiche NetAlarm2
 *     
*/
//$.ajaxSetup({
//  headers: {
//    //'X-CSRF-Token': csrfToken
//  }
//});
function sendMessage(outgoingMessage) {
  console.log('function sendMessage - msg: '+JSON.stringify(outgoingMessage));
  $('#led').css('background-color', 'red');
  $.ajax({
    url:  '/na2/api',
    type: 'POST',
    contentType: 'application/json',
    dataType: 'json',
    data: JSON.stringify(outgoingMessage)
  });
}
$(document).ajaxSuccess(function(event, xhr, settings) {
  if(xhr.status === 200){
    $('#led').css('background-color', 'green');
  }
  console.log('ajax success - xhr.status: '+xhr.status);
  console.log('ajax success - responseJSON: '+JSON.stringify(xhr.responseJSON));
});
$( document ).ajaxError(function(event, xhr, settings) {
  var resp = xhr.responseText
  ;
  console.log('ajax ERROR - xhr: '+JSON.stringify(xhr));
});

function simulinit() {
  console.log('start simulinit()');
  //-------------------------------------------------------------  Emissione configurazione iniziale
  $('#vai').on('click',function(e){
    e.preventDefault();
    //--------------------------------------------------------------  Emissione messaggio di allarme
    sendMessage(alarmmsg);
    console.log('Emesso allarme: '+JSON.stringify(alarmmsg));
  });
  
  clearInterval(tick);
  tick = start_periodic_tick(tick_interval);// esecuzione periodica di funzioni varie
}
$(document).on('ready', function(){
  simulinit();
}
);
