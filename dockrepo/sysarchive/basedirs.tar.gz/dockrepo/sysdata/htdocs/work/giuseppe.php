<?PHP
  phpinfo()
?>   