-- file DA AGGIUSTARE
-- dovrebbe servire come test
--
ngx.header.content_type = 'text/html' 
local name = ngx.var.arg_name or "Tester"
ngx.say("<br>Hello, ", name, "!<br>")
ngx.say("This is a test for the LUA interpreter, run by the gothings NGINX http proxy<br>")
ngx.say("<br><hr><br>")
ngx.say("If you see this file it means that:<br>")
ngx.say(" &nbsp; &nbsp; - nginx HTTP proxy is running OK<br>")
ngx.say(" &nbsp; &nbsp; - configuration files enable the test location<br>")
ngx.say(" &nbsp; &nbsp; - LUA interpreter is correctly configured into nginx<br>")
ngx.say(" &nbsp; &nbsp; - serving content by LUA interpreter is OK<br>")
ngx.say("<br><hr><br>")
ngx.say("This page is printed by the LUA interpreter, using statements like ngx.say(\"... \") <br><br>")
ngx.say("You can test more content going back to the &nbsp; <a href=\"/\">homepage</a><br>")
ngx.say("<br><hr><br>")
ngx.say("<br>Notes:<br>")
ngx.say(" &nbsp; &nbsp; - LUA version number: "..ngx.config.nginx_version.."<br>")
ngx.say(" &nbsp; &nbsp; - HTTP host: ",ngx.var.http_host,"<br>")
ngx.say(" &nbsp; &nbsp; - Docker container: ",ngx.var.hostname,"<br>")
ngx.say(" &nbsp; &nbsp; - This file filename is:  'index.lua'<br>")
ngx.say(" <hr>&nbsp; &nbsp; - Questo file va AGGIUSTATO !!!<br>")
ngx.say("<br><hr>")
