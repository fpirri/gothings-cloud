/* 
 * per far partire socket.io con i parametri giusti
 */

//var socket = io.connect("http://himage2.com:3000/espo");
//socket.on('message', function(d){console.log(d);});

// **************   DA IMPLEMENTARE                  *** posto per la parte comune ***
