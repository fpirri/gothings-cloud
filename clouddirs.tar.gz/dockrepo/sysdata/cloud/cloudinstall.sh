#!/bin/bash
#
#  install nodejs modules for gothings cloud
#
########
#  
#    
###
echo
echo "------------------------"
echo "  Start GoThings CLOUD"
echo "------------------------"
echo
#
local app message appdir appinjstall
app="cloud"
message="install GoThings CLOUD environment"
appdir="/home/pi/dockrepo/sysdata/${app}"
#
cd "${appdir}"
echo
echo "${app}: ${message}"
echo
echo "Starting docker-compose ..."
#docker-compose -f "/home/pi/dockrepo/sysdata/${app}/gothings${app}install.yml" up -d
echo "eseguirei il compose 
echo
echo "${app}: ${message}"
echo "  DONE -----------------------------"
echo 